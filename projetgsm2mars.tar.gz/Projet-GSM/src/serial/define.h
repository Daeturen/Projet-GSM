#ifndef DEFINE_INC
#define DEFINE_INC


/////////
#define DEBUG //debug
/////////

#define TIMEOUT 200000
#define DEFAULT_PHONE "0768588348"

#define ACTIONVALIDE "act"
#define ACTION_SHUTDOWN "shutdown"
#define NUMERO "+33"
#define ACTION_1_ON	"1 ON"
#define ACTION_2_ON	"2 ON"
#define ACTION_3_ON	"3 ON"
#define ACTION_4_ON	"4 ON"
#define ACTION_5_ON	"5 ON"
#define ACTION_6_ON	"6 ON"
#define ACTION_7_ON	"7 ON"
#define ACTION_1_OFF "1 OF"
#define ACTION_2_OFF "2 OF"
#define ACTION_3_OFF "3 OF"
#define ACTION_4_OFF "4 OF"
#define ACTION_5_OFF "5 OF"
#define ACTION_6_OFF "6 OF"
#define ACTION_7_OFF "7 OF"


#endif
